<!DOCTYPE html> 
<html lang="id"> 
<head> 
    <meta charset="UTF-8"> 
    <title><?= $title; ?></title> 
</head> 
<body> 
    <?= $this->include('template/header'); ?>

    <h1><?= $title; ?></h1>
    <hr>
    <p><?= $content; ?></p>

    <form>
        <label for="name">Nama:</label>
        <input type="text" id="name" name="name">

        <label for="email">Email:</label>
        <input type="email" id="email" name="email">

        <label for="message">Pesan:</label>
        <textarea id="message" name="message"></textarea>

        <button type="submit">Kirim</button>
    </form>

    <?= $this->include('template/footer'); ?> 
</body> 
</html>
