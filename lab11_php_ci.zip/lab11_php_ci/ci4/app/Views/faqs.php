<!DOCTYPE html> 
<html lang="id"> 
<head> 
    <meta charset="UTF-8"> 
    <title><?= $title; ?></title> 
</head> 
<body> 
    <?= $this->include('template/header'); ?>

    <h1><?= $title; ?></h1>
    <hr>
    <p><?= $content; ?></p>
    <ul>
        <li><strong>Pertanyaan 1:</strong> Jawaban...</li>
        <li><strong>Pertanyaan 2:</strong> Jawaban...</li>
    </ul>

    <?= $this->include('template/footer'); ?> 
</body> 
</html>
