<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $title; ?></title>
    <link rel="stylesheet" href="<?= base_url('/style.css');?>">
</head>
<body>
    <div id="container">
    <header>
        <h1>Website saya</h1>
    </header>
    <nav>
        <a href="<?= base_url('/');?>">Home</a>
        <a href="<?= base_url('/about');?>">About</a>
        <a href="<?= base_url('/contact');?>">Contact</a>
        <a href="<?= base_url('/faqs');?>">Faq</a>
        <a href="<?= base_url('/tos');?>">Terms of Service</a>
    </nav>
    <section id="wrapper">
    <section id="main">
