<?php 
    namespace App\Controllers; 
    class Page extends BaseController 
    { 
        public function about()
        {
            return view('about', [
                'title' => 'Halaman About',
                'content' => 'Ini adalah halaman About yang menjelaskan
                tentang isi halaman ini.'
            ]);
        }
        public function contact() 
        { 
            return view('contact', [
                'title' => 'Halaman Contact',
                'content' => 'Silakan hubungi kami melalui formulir di bawah ini.'
            ]); 
        } 
        public function faqs() 
        { 
            return view('faqs', [
                'title' => 'Halaman FAQ',
                'content' => 'Ini adalah halaman FAQ yang berisi pertanyaan yang sering diajukan.'
            ]);
        } 
        public function tos() 
        {
            return view('tos', [
                'title' => 'Halaman Terms of Service',
                'content' => 'Ini adalah halaman Terms of Service yang menjelaskan syarat dan ketentuan penggunaan layanan kami.'
            ]);    
        }
    }